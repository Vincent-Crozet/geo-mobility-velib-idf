-- dbt/models/staging/stg_geo_communes_idf.sql

SELECT c.insee::int,
    c.nomcom::text,
    c.numdep::int,
    c.geometry
FROM {{ source('geo_asset', 'communes_idf') }} AS c
